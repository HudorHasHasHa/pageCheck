npm install,
npm run watch,